<link rel="icon" href="<?php echo base_url();?>css/img/diary.png" sizes="16x16" type="image/png">
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">

  	<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
  	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
  	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/mstyle.css">
  	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  	<script src="<?php echo base_url(); ?>js/jquery.js"></script>
  	<script src="<?php echo base_url(); ?>js/bootstrap.bundle.min.js"></script>
  	<script type="text/javascript" src="<?php echo base_url(); ?>js/main.js">
  	</script>